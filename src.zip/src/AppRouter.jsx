import { createBrowserRouter } from "react-router";
import AppLayout from "./AppLayout";
import Home from "./pages/Home";
import Category from "./pages/Category"
import Product from "./pages/Product";
import Order from "./pages/Order";
import Contact from "./pages/Contact";
import About from "./pages/About";
import Cart from "./pages/Cart";
import Signup from "./pages/Signup";
import Signin from "./pages/Signin";
import NotFound from "./pages/NotFound";

const router = createBrowserRouter([
    {
        path: "/",
        Component: AppLayout,
        children:[
            {
                index: true,
                Component: Home
            },
            {
                path: "category",
                Component: Category
            },
            {
                path: "product",
                Component: Product
            },
            {
                path: "order",
                Component: Order
            },
            {
                path: "contact",
                Component: Contact
            },
            {
                path: "about",
                Component: About
            },
            {
                path: 'cart',
                Component: Cart
            },
            {
                path: "signup",
                Component: Signup
            },
            {
                path: "signin",
                Component: Signin
            }
        ]
    },
    {
        path: "*",
        Component: NotFound
    }
])

export default router