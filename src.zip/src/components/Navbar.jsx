import React from 'react'
import { FaShoppingCart } from 'react-icons/fa'
import { Link } from 'react-router'

function Navbar() {
  return (
    <header className="mb-5 inset-x-0 top-0 z-30 mx-auto w-full max-w-screen-md border border-gray-100 bg-white/80 py-3 shadow backdrop-blur-lg md:top-6 md:rounded-3xl lg:max-w-screen-lg">
  <div className="px-4">
    <div className="flex items-center justify-between">
      <div className="flex shrink-0">
        <Link aria-current="page" className="flex items-center " to={"/"}>
          <img
            className="h-7 w-auto"
            src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg"
            alt=""
          />
          <p className="sr-only">CT Shopping</p>
        </Link>                                     
      </div>
      <div className="hidden md:flex md:items-center md:justify-center md:gap-5">
        <Link
          aria-current="page"
          className="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
          to={"/"}
        >
          หน้าหลัก
        </Link>
        <Link
          className="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
          to={"category"}
        >
          หมวดสินค้า
        </Link>
        <Link
          className="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
          to={"product"}
        >
          สินค้า
        </Link>
        <Link
          className="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
          to={"order"}
        >
          สั่งซื้อ
        </Link>
        <Link
          className="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
          to={"contact"}
        >
          ติดต่อเรา
        </Link>
        <Link
          className="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
          to={"about"}
        >
          เกี่ยวกับเรา
        </Link>
      </div>
      <div className="flex items-center justify-end gap-3">

        <Link to={"cart"}>
            <FaShoppingCart className='text-blue-600 text-3xl' />
        </Link>

        <Link
          className="hidden items-center justify-center rounded-xl bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 transition-all duration-150 hover:bg-gray-50 sm:inline-flex"
          to={"signup"}
        >
          สมัครสมาชิก
        </Link>
        <Link
          className="inline-flex items-center justify-center rounded-xl bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow-sm transition-all duration-150 hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          to={"signin"}
        >
          เข้าสู่ระบบ
        </Link>
      </div>
    </div>
  </div>
</header>

  )
}

export default Navbar