import React from 'react'

function ProductCard(props) {
  const {id, title, price, thumbnail } = props
  return (
    <div className='w-48 h-64 rounded-xl shadow-xl bg-blue-200 overflow-hidden'>
        <img src={thumbnail} alt={`pic${id}`} />
        <p className='text-xl'>{title}</p>
        <p>{price}</p>
    </div>
  )
}

export default ProductCard