import React from 'react'
import { FaLine } from 'react-icons/fa';
import { Link, NavLink } from 'react-router';
import Button from '../components/Button';

function Home() {
  return (
    <div>
      <Link to={"https://www.facebook.com"}>Go Facebook</Link>
      <Link to={'https://www.line.me'}>
        <FaLine className='text-green-500 text-4xl' />
      </Link>

      <NavLink to={"about"}>About</NavLink>
      <hr />
      <Button text={"ไปหน้าสั่งซื้อ"} url={"order"} />
    </div>
  )
}

export default Home