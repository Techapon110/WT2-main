import React, { useState } from 'react'

function Signin() {

  const [isShow, setIsShow] = useState(false)
  return (
    <div>
      <input onChange={e => setIsShow(e.target.checked)} type="checkbox" name="show" id="show" />
      <label htmlFor="show">Show</label>
      <hr className='m-5' />
      <p>{ isShow && <img src='https://picsum.photos/300/200?random=1' alt='pic' /> }</p>
    </div>
  )
}

export default Signin