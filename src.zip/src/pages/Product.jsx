import React, { useEffect, useState } from 'react'
import { Await } from 'react-router';
import ProductCard from '../components/ProductCard';


function Product() {
  const [products, setProducts] = useState(null)

  useEffect(() => {
    async function getProduct() {
      await fetch("https://dummyjson.com/products")
      .then(res => res.json())
      .then(data => setProducts(data.products))
    }
  
    getProduct()
  }, [])
  
  if(!products) return <p className="tec-2xl">Loading......</p>

  return (
    <div className="container flex flex-wrap gap-5 m-5 animate-in duration-300 fade-in zoom-in">
        {
        products && products.map( p => <ProductCard key={p.id} {...p}/>)
        }
    </div>
  )
}

export default Product











// import React from "react";
// import ProductCard from "../components/ProductCard";

// const name = "Computer RMU";
// const count = 20;
// const product = {
//   id: 1,
//   name: "iPhone 17 Pro",
//   price: 50000,
//   img: "https://picsum.photos/240/200?random=1",
// };

// const products = [
//   {
//     id: 1,
//     name: "iPhone 17 Pro",
//     price: 50000,
//     img: "https://picsum.photos/240/200?random=1",
//   },
//   {
//     id: 2,
//     name: "Samsung S26",
//     price: 45000,
//     img: "https://picsum.photos/240/200?random=2",
//   },
//   {
//     id: 3,
//     name: "Vivo Y30",
//     price: 9000,
//     img: "https://picsum.photos/240/200?random=3",
//   },
//   {
//     id: 4,
//     name: "Xiaom S16",
//     price: 12000,
//     img: "https://picsum.photos/240/200?random=4",
//   },
//   {
//     id: 5,
//     name: "Vivo v50",
//     price: 20000,
//     img: "https://picsum.photos/240/200?random=5",
//   }
// ];

// function Product() {
//   return (
//     <div className="container flex gap-5 flex-wrap duration-300 animate-in fade-in zoom-in">
//       {products.map((p) => (
//         <ProductCard key={p.id} {...p} />
//       ))}

//       {/* <ProductCard {...product} />
//       <ProductCard id={product.id} name={product.name} price={product.price} img={product.img} />
//       <ProductCard id={2} name={"Samsung S25"} price={40000} img={"https://picsum.photos/240/200?random=2"} />
//       <ProductCard id={3} name={"Oppo V20"} price={9000} img={"https://picsum.photos/240/200?random=3"} />
//       <ProductCard id={4} name={"Xiaomi S20"} price={4500} img={"https://picsum.photos/240/200?random=4"} /> */}

//       {/* <p className="text-xl">Product ID : {product.id}</p>
//       <p className="text-xl">Product Name : {product.name}</p>
//       <p className="text-xl">Product Price: {product.price}</p>

//       <hr />
//       <p className="text-xl">My name : { name }</p>
//       <p className="text-xl">Count : { count + 10 }</p> */}
//     </div>
//   );
// }

// export default Product;
