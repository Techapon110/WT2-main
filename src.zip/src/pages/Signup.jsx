import React, { useState } from 'react';


function Signup() {

  //const [username, setUsername] = useState('')
  //const [email, setEmail] = useState('')
  //const [password, setPassword] = useState('')
  //const [passwordConfirm, setPasswordConfirm] = useState('')

  const [user, setUser] = useState('')
  
  return (
<div className="bg-gray-100 flex h-screen items-center justify-center px-4 sm:px-6 lg:px-8">
  <div className="w-full max-w-md space-y-8">
    <div className="bg-white shadow-md rounded-md p-6">
      <img
        className="mx-auto h-12 w-auto"
        src="https://www.svgrepo.com/show/499664/user-happy.svg"
        alt=""
      />
      <h2 className="my-3 text-center text-3xl font-bold tracking-tight text-gray-900">
        สมัคสมาชิก
      </h2>
      <form className="space-y-6" >
        <div>
          <label
            htmlFor="username"
            className="block text-sm font-medium text-gray-700"
          >
            ชื่อผู้ใช้
          </label>
          <div className="mt-1">
            <input
              onChange={(e)=>setUser({...user, username: e.target.value})}
              id="username"
              type="text"
              required
              className="px-2 py-3 mt-1 block w-full rounded-md border border-gray-300 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-sky-500 sm:text-sm"
            />
          </div>
        </div>
        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-700"
          >
            อีเมล
          </label>
          <div className="mt-1">
            <input
            onChange={e => setUser({...user, email: e.target.value})}
              id="email"
              type="email"
              required
              className="px-2 py-3 mt-1 block w-full rounded-md border border-gray-300 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-sky-500 sm:text-sm"
            />
          </div>
        </div>
        <div>
          <label
            htmlFor="password"
            className="block text-sm font-medium text-gray-700"
          >
            รหัสผ่าน
          </label>
          <div className="mt-1">
            <input
            onChange={e => setUser({...user, password: e.target.value})}
              id="password"
              type="password"
              required
              className="px-2 py-3 mt-1 block w-full rounded-md border border-gray-300 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-sky-500 sm:text-sm"
            />
          </div>
        </div>
        <div>
          <label
            htmlFor="confirm_password"
            className="block text-sm font-medium text-gray-700"
          >
            ยืนยันรหัสผ่าน
          </label>
          <div className="mt-1">
            <input
            onChange={e => setUser({...user, passwordConfirm: e.target.value})}
              id="confirm_password"
              type="password"
              required
              className="px-2 py-3 mt-1 block w-full rounded-md border border-gray-300 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-sky-500 sm:text-sm"
            />
          </div>
        </div>
        <div>
          <button
            type="button"
            className="flex w-full justify-center rounded-md border border-transparent bg-green-400 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-opacity-75 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-offset-2"
          >
            สมัคสมาชิก
          </button>
        </div>
      </form>
    </div>
  </div>
  <p>User: {JSON.stringify(user)}</p>

</div>

  )
}

export default Signup