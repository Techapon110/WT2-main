import React, { useEffect, useState } from 'react'

function Category() {
  const [ct, setCt] = useState (null)
  const [clock, setClock] = useState(new Date())
  const [count, setCount] = useState(0)

  useEffect(() => {
    setCt(`Hello CT Effect : ${count}`)
  }, [count])
  
  useEffect(() => {
    const timer = setInterval(() => {
      setClock(new Date())
    }, 1000);
  
    return () => {
      clearInterval(timer)
    }
  }, [])
  
  


  return (
    <div>
      <p className="text-5xl">{ct}</p>
      <p>{clock.toLocaleString()}</p>
      <p className="my-3">Show Count : {count}</p>
      <button onClick={()=>setCount(count+1)} className="bg-blue-500 text-white px-3 py-2 my-3">Count UP</button>
    </div>
  )
}

export default Category