import React from 'react'

function NotFound() {
  return (
    <div className="container h-screen flex justify-center items-center">
        <p className="text-red-500 text-6xl">ไม่พบหน้านี้</p>
    </div>
  )
}

export default NotFound