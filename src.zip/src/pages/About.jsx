import React from 'react'
import { FaFacebook, FaYoutube, FaLine } from 'react-icons/fa6'

const myStyle = { color:"red", fontSize: 50 }


function About() {
  return (
    <div>
        <p className='text-blue-600 text-6xl text-shadow-2xs' >เกี่ยวกับเทคโนคอม</p>
        <img src="https://picsum.photos/300/200?random=1" alt="pic" />
        <hr />
        <FaFacebook className='text-8xl text-blue-600' />
        <FaYoutube size={50} color='red' />
        <FaLine size={50} color='green' />
        <hr />
        <p style={myStyle} >Computer Technology</p>
    </div>
  )
}

export default About